#!/bin/bash
# founderctl.sh start|stop|status — start/stop the scheduled Founder planner.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
PLIST_DST="$HOME/Library/LaunchAgents/com.founder.planner.plist"
CMD="${1:-}"

case "$CMD" in
  start)
    mkdir -p "$HOME/Library/LaunchAgents"
    cp "$DIR/com.founder.planner.plist" "$PLIST_DST"
    launchctl unload "$PLIST_DST" 2>/dev/null || true
    launchctl load "$PLIST_DST"
    echo "Founder ON - runs hourly 6AM-10PM."
    ;;
  stop)
    launchctl unload "$PLIST_DST" 2>/dev/null || true
    rm -f "$PLIST_DST"
    echo "Founder OFF."
    ;;
  status)
    if [ "$(launchctl list | grep -c com.founder.planner)" != "0" ]; then
      echo "Founder: ON"
    else
      echo "Founder: OFF"
    fi
    ;;
  *)
    echo "Usage: $0 start|stop|status"
    exit 1
    ;;
esac