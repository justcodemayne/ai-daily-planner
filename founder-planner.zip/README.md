# FOUNDER — AI Daily Planner

[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Platform: macOS](https://img.shields.io/badge/platform-macOS-lightgrey.svg)](#)
[![Dependencies: none](https://img.shields.io/badge/dependencies-none-brightgreen.svg)](#)

Founder reads what you want to do today, respects the fixed parts of your day
(work, meetings, meals, bedtime…), emails you a plan at 6:00 AM, listens to
your email replies (`done` / `skip` / `add:`), and gently learns how you work.

It turns a plain-English to-do list into a real, time-blocked day using an LLM,
then adapts to how you actually perform — no app to open, no dashboard to babysit.

```
🟢 Your plan is ready — 7 tasks, 4h 30m of focus time

09:00–10:30  Finish the project proposal        [t1]  DEEP
10:30–10:40  Break
10:40–11:00  Reply to the client email          [t2]  (due 10am ✅)
12:30–13:15  Lunch                              LOCKED
18:00–19:00  Gym                                [t3]  LOCKED
...
```

It runs entirely on your Mac:

- **Groq API** (free) for language understanding — it turns your plain-English
  to-do list into structured, schedulable tasks.
- **Gmail SMTP + IMAP** (send + read) using an App Password — no third-party
  bridge needed.
- **launchd** runs `founder.py` every hour from 6 AM to 10 PM (see
  `com.founder.planner.plist`).
- **macOS `pmset`** can wake the Mac for the day and sleep it at night
  (configured with `--setup-power`).

---

## Controls

| Command | What it does |
|---------|--------------|
| `founder-on` | Start Founder (runs hourly, 6AM–10PM) |
| `founder-off` | Stop Founder |
| `founder-status` | Show if Founder is ON or OFF |

*(Aliases live in `~/.zshrc` and point at `founderctl.sh` in this folder.
Open a new terminal or run `source ~/.zshrc` after editing `~/.zshrc`.)*

---

## Files

| File | Purpose | You edit? |
|------|---------|-----------|
| `founder.py` | The whole planner (settings at the top, `SETTINGS`) | Yes — config only |
| `daily_tasks.txt` | Today's to-do list — one plain-English line per task | Yes, every day |
| `constraints.txt` | Fixed, non-negotiable parts of your day | Yes, occasionally |
| `log.txt` | Learning data — every planned/done/skip event (`date\|kind\|desc\|minutes`) | No (auto) |
| `log_state.json` | Today's plan + reply-polling state | No (auto) |
| `runtime.log` | launchd output/errors for every scheduled run | No (auto) |
| `com.founder.planner.plist` | The launchd schedule (hourly 6AM–10PM) | No |
| `founderctl.sh` | `start \| stop \| status` for the launch agent | No |
| `install_launchagent.sh` | One-shot installer that rewrites the path into the plist | No |
| `settings.json.example` | Reference template mirroring `SETTINGS` (not loaded at runtime) | No |

---

## How a day works

1. **06:00 / first run after** — `auto_route()` checks whether today's plan was
   already emailed. If not, it calls `plan_today()`: Founder reads
   `daily_tasks.txt`, parses each line into a task (duration, deadline, fixed
   start, earliest start, deep/light focus) via Groq, applies any
   personalization learned from `log.txt`, and fits everything into the gaps
   your constraints leave free.
2. **Email out** — you get a styled HTML plan (with a plain-text twin) and every
   task is tagged `[t1]`, `[t2]`, … . Deep-focus tasks go in your `peak:`
   window; locked events are never moved.
3. **All morning/day long** — every hour Founder polls the inbox for replies
   (subject must contain `[FNDR]`). If you replied `done [t1]`, `skip [t2]` or
   `add: <task>`, it rebuilds the rest of the day **and emails you the updated
   plan**.
4. **21:00 rollover** — unfinished tasks carry over into tomorrow's list; the
   file is otherwise cleared.
5. **22:00 clear** — `daily_tasks.txt` is emptied entirely so tomorrow starts
   with a clean slate (change `clear_hour` in `founder.py` to move the time).
6. **Sunday 06:00** — a weekly digest: tasks done, focus time, missed tasks,
   most-frequent wins, streaks, and “watch-outs” Founder will now cushion.

### Reliability — don't rely on being awake at 6 AM

The 6:00 AM trigger only fires if the Mac is awake. If it isn't, launchd runs
the job when the Mac wakes — and `auto_route()` **retries the plan at any hour
before the 21:00 rollover** instead of silently skipping the day. A transient
Groq/SMTP failure also records itself and retries next hour rather than
crashing the run.

Every running hour is logged to `runtime.log`; check it first if a plan ever
goes missing.

---

## Setup (do this once)

### 1. Email (Gmail, send + read)

Founder **sends and reads** email through Gmail using an App Password:

1. Get a Gmail account (a dedicated one works best) set up with
   **2-Step Verification**, then create an **App Password** at
   https://myaccount.google.com/apppasswords.
2. Put the 16-character App Password (no spaces) in the `mail_password` line of
   `founder.py`, or in `settings.json` (recommended).
3. Set `email_to` to the address where you want your plans delivered.

```python
"email_from":      "your.bot@gmail.com",           # the planner Gmail (sender + login)
"email_to":        "you@gmail.com",                 # where the schedule is delivered
"smtp_host":       "smtp.gmail.com",   # leave as-is
"smtp_port":       587,                # leave as-is
"imap_host":       "imap.gmail.com",   # leave as-is
"imap_port":       993,                # leave as-is
"mail_username":   "your.bot@gmail.com",
"mail_password":   "your-16-char-app-password",     # NOT your normal Gmail password
```

> **Security:** never commit real credentials. The recommended way to keep
> secrets out of the code is to copy `settings.json.example` to `settings.json`
> and put your email password and Groq key there — `settings.json` is
> git-ignored. The values in `founder.py` ship empty on purpose.

### 2. AI — Groq

Grab a free API key at https://console.groq.com and put it in `groq_api_key`.
The model is `openai/gpt-oss-120b` (`llm_model`); if the API fails three times
in a row you'll see:

```
Founder Error, check your Groq API key, your internet connection and the Groq
service status (https://status.groq.com) to resolve this issue.
```

### 3. Fill in your input files

See the two sections below (`daily_tasks.txt` and `constraints.txt`).

### 4. Test before going live

From inside this folder, run these in order:

```bash
python3 founder.py --dry-run     # print today's plan WITHOUT emailing (best first step)
python3 founder.py --plan        # actually email today's plan
python3 founder.py --check       # poll the inbox for replies right now
python3 founder.py --digest      # force the weekly digest now
python3 founder.py --add "call dentist 15min"   # add a task without editing the file
python3 founder.py --replan      # resend today's plan immediately (an "Updated plan" email)
```

- `--dry-run` calls Groq and prints the exact email but sends nothing — run it
  first whenever you change tasks or constraints.
- `--plan` sends for real; check the inbox (and **junk/spam**) for the `[FNDR]`
  subject.
- Reply to a plan with `done [t1]` / `add: something`, then run `--check` to
  watch Founder rebuild the day.

### 5. Install the automatic schedule

```bash
./install_launchagent.sh                       # installs the hourly 6AM–10PM agent
sudo python3 founder.py --setup-power          # wake at 06:00, sleep at 23:45
```

The install script copies `com.founder.planner.plist` to
`~/Library/LaunchAgents/` and rewrites the absolute path to match this folder,
so it survives moving the folder. Verify with:

```bash
launchctl list | grep founder
```

> Notes:
> - The launch agent only runs while the Mac is awake. `--setup-power` (needs
>   **sudo**) makes the Mac wake itself for the day and sleep at night — run it
>   once or the Mac may be asleep when your plan should go out.
> - Founders live under `~/Documents`, which macOS can restrict for launchd
>   jobs (`[Errno 1] Operation not permitted`). If that ever appears in
>   `runtime.log`, re-run `./install_launchagent.sh` so the path is correct, and
>   grant Full Disk Access to `/usr/bin/python3` in
>   System Settings → Privacy & Security → Full Disk Access.

---

## `daily_tasks.txt` — plain English is fine

Write anything you want to do, one line per task. Founder's LLM understands
natural language, durations, deadlines, and fixed times.

```
finish the project proposal 90min
reply to the client email before 10am
call the dentist
gym at 6pm for an hour
pick up groceries after work, 30 min
review the design doc
```

Lines starting with `#` are ignored (handy for notes or temporarily disabling
tasks).

### Denoting time in a task

| Kind | How to write it | What Founder does |
|------|-----------------|-------------------|
| **Duration** | `90min`, `for an hour`, `30 min` | Blocks that amount of time (defaults to 30) |
| **Deadline** | `before 10am`, `deadline 16:00` | Must finish *by* this time — slots it earlier if needed |
| **Earliest start** | `after 4pm`, `not before 5`, `after 16:00` | Never scheduled before this time |
| **Fixed time** | `at 6pm`, `fixed 18:00` | Pinned — must start at exactly this time, never moved |
| **Focus** | `focus deep` (or `focus light`) | Deep tasks get priority in your `peak:` window |

Rule of thumb: `before …` / `deadline …` = finish by; `at …` / `fixed …` =
start exactly at; `after …` / `not before …` = earliest start; no time = fully
flexible, Founder picks the best gap.

---

## `constraints.txt` — the fixed, non-negotiable parts of your day

These are parsed deterministically (no AI), because your schedule must never
break them.

| Line | Meaning |
|------|---------|
| `work: 09:00-17:00` | Blocked for work |
| `school: 13:00-15:00` | Blocked for class (also `class:` / `commute:`) |
| `lunch: 12:30 45min` | Lunch (time + optional length) |
| `block: Gym 18:00-19:00` | A fixed appointment (also works with `meeting:` / `appointment:`) |
| `meal: Breakfast 20min 16:30-18:30` | A meal ritual — auto-slotted inside the window |
| `peak: 09:00-12:00` | Your deep-focus window (deep tasks go here first) |
| `day: 07:00-22:00` | Overall window Founder may schedule in |
| `prefer: deep` | Put focus tasks in the morning |

**Day filters** — prefix any line so it only applies certain days. Stack as
many as you want:

| Filter | Runs when |
|--------|-----------|
| `@weekday` / `@weekend` | Mon-Fri / Sat-Sun |
| `@mon @tue @wed @thu @fri @sat @sun` | That weekday (also `@mon-fri`, `@tue,thu`) |
| `@day1` / `@day2` | Alternating school days (Day 1 anchored Fri 2026-09-11) |
| `@school` | A school day: weekday, not a US federal holiday, not in `school-off:` |
| `@everyN:YYYY-MM-DD` | Every N days from the anchor date (e.g. biweekly weigh-in) |

`school-off: 2026-11-26, 2026-12-25` — extra days school is out. US federal
holidays are skipped automatically; weekends never count as school days.

Lines starting with `#` are comments. If the file is empty, Founder uses
built-in defaults (8:00–22:00 window, lunch at 12:30) and leaves the whole day
flexible.

---

## Replying to your plan (emailing Founder back)

Every plan email tags its tasks like `[t1]`, `[t2]`, …. Reply to the email and
tell Founder what happened; it updates its records and emails you a **rebuilt
schedule** with whatever is left.

```
done with [t1]
finished [t3]
skipped [t2]
add: prep the slide deck for tomorrow
```

You can also refer to tasks by name instead of tag:

```
finished the proposal, and groceries are done too
```

- Always use **Reply** so the subject keeps the `[FNDR]` tag — that's how
  Founder finds your replies.
- When everything is cleared, you get an **"All clear"** email.
- Your outcomes are recorded in `log.txt`: tasks you skip/struggle with get
  extra time and are moved to your focus window; tasks you finish fast get
  shortened to your real pace.

---

## Personalization (how Founder learns)

`plan_today()` applies what it learned from `log.txt` before scheduling:

- **Struggle cushion** — descriptions that have been skipped/struggled with get
  ~125% of their estimated time +10 min and are marked deep-focus.
- **Actual pace** — tasks you've finished before get scheduled at your real
  average duration instead of the AI's guess (min floor 15 min).
- **Dedupe** — only the first "planned" entry per description per day is
  written, so repeated `--plan`/`--replan` runs don't skew the average.

---

## Weekly digest

Every **Sunday** at 06:00 you get a digest with:

- tasks completed, focus time spent, tasks missed
- your most-frequent wins
- milestone streaks (e.g. "6-day completion streak")
- watch-outs — the tasks Founder will now cushion for you

To change the day, set `digest_day` in `founder.py` (0=Monday … 6=Sunday).

---

## Common issues

| Symptom | Fix |
|---------|-----|
| Email sent but never arrived | Check **junk/spam**; verify `email_to`; confirm the App Password is valid; re-send with `--plan` |
| `Founder Error, check your Groq API key…` | Key missing/invalid, offline, or Groq down → check `groq_api_key`, internet, and https://status.groq.com |
| App Password rejected | Must be a 16-char **App Password** (no spaces), not your normal password |
| No plan in the morning | It only sends if the Mac is awake by ~06:00 → run `--setup-power` (sudo) to wake it; missed runs retry hourly before 21:00 now |
| `[Errno 1] Operation not permitted` in runtime.log | launchd is blocked from `~/Documents` → re-run `./install_launchagent.sh`, and grant Full Disk Access to `/usr/bin/python3` |
| Plan didn't arrive | Run `python3 founder.py --plan` manually — the exact error prints to your terminal |