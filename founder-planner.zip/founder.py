#!/usr/bin/env python3
# ============================================================================
#  F O U N D E R  -  Your daily AI schedule planner
#  Reads what you want to do today, builds a day that respects how you live,
#  emails it at 6:00, listens to your email replies (done/skip/add), and
#  re-plans around them. The day rolls over at 9:00 PM.
#
#  >>>  SETUP: fill in the marked lines below.                          <<<<<<
#  >>>  Fill in daily_tasks.txt and constraints.txt (see formats).      <<<<<<
#  >>>  Gmail 2-Step Verification + app password for SMTP.               <<<<<<
# ============================================================================

SETTINGS = {
    # --- EMAIL (send-only via Gmail SMTP; no inbox required) ---
    # >>> Never commit real credentials. Either edit the fields here locally,
    # >>> or (recommended) put them in settings.json, which is git-ignored.
    "email_from":      "your.bot@gmail.com",   # <<< planner Gmail (sender)
    "email_to":        "you@gmail.com",        # <<< where the schedule is delivered
    "smtp_host":       "smtp.gmail.com",      # Gmail SMTP (leave as-is)
    "smtp_port":       587,                   # Gmail SMTP port (leave as-is)
    "smtp_starttls":   True,                  # Gmail requires STARTTLS (leave as-is)
    "imap_host":       "imap.gmail.com",      # not used in send-only mode
    "imap_port":       993,                   # not used in send-only mode
    "mail_username":   "your.bot@gmail.com",  # <<< planner Gmail (login)
    "mail_password":   "",                    # <<< Gmail APP PASSWORD (not your normal one)

    # --- AI (Groq API only - no local fallback) ---
    "groq_api_key":    "",                    # <<< https://console.groq.com -> free key
    "llm_model":       "openai/gpt-oss-120b",
    "polish_email":    False,                 # let the LLM prettify plan emails

    # --- DAY STRUCTURE ---
    "day_start":       "08:00",               # earliest time tasks are placed
    "day_end":         "22:00",               # latest time tasks are placed
    "lunch":           "12:30",
    "lunch_min":       45,
    "break_every_min": 90,
    "break_min":       10,
    "default_task_min": 30,

    # --- POWER (wake for the day, sleep at night) ---
    "wake":            "06:00",
    "sleep":           "23:45",

    # --- PLANNING SCHEDULE ---
    "plan_hour":       6,                     # plan email at 6:00 AM
    "digest_day":      6,                     # 0..6 = Mon..Sun (6 = Sunday digest)
    "rollover_hour":   21,                    # hour the day turns over (9:00 PM)
    "clear_hour":      22,                    # hour daily_tasks.txt is emptied (10:00 PM)
}

# ============================================================================
import argparse
import datetime as dt
import html as html_escape
import imaplib
import json
import re
import smtplib
import subprocess
import sys
import time
import urllib.error
import urllib.request
from email import message_from_bytes
from email.header import Header
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

BASE = Path(__file__).resolve().parent
TASKS_FILE = BASE / "daily_tasks.txt"
CONSTRAINTS_FILE = BASE / "constraints.txt"
LOG_FILE = BASE / "log.txt"
STATE_FILE = BASE / "log_state.json"

DONE_WORDS = ("done", "finished", "finish", "completed", "complete", "ok", "wrapped", "cleared")
SKIP_WORDS = ("didn't", "didnt", "couldn't", "couldnt", "not done", "skipped", "skip", "struggled",
              "too long", "too much", "cancel", "pushed", "won't", "wont", "gave up", "failed")


def log(msg):
    print(f"[{dt.datetime.now():%H:%M:%S}] {msg}", flush=True)


def tmin(hhmm):
    h, m = str(hhmm).split(":", 1)
    return int(h) * 60 + int(m)


def tstr(mins):
    return f"{mins // 60:02d}:{mins % 60:02d}"


def read_lines(path):
    if not path.exists():
        return []
    return [ln.strip() for ln in path.read_text().splitlines()
            if ln.strip() and not ln.lstrip().startswith("#")]


def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {}


def save_state(state):
    STATE_FILE.write_text(json.dumps(state, indent=2))


def log_event(date_str, kind, desc, minutes):
    with open(LOG_FILE, "a") as f:
        f.write(f"{date_str}|{kind}|{desc}|{minutes}\n")


def log_planned(day, tasks):
    already = set()
    if LOG_FILE.exists():
        for ln in LOG_FILE.read_text().splitlines():
            parts = ln.split("|")
            if len(parts) >= 4 and parts[0] == day.isoformat() and parts[1] == "planned":
                already.add(parts[2].lower().strip())
    for t in tasks:
        if t["description"].lower().strip() not in already:
            log_event(day.isoformat(), "planned", t["description"], t["minutes"])
            already.add(t["description"].lower().strip())


# ---------------------------------------------------------------------------
#  LLM
# ---------------------------------------------------------------------------

def llm_endpoint(settings):
    key = settings.get("groq_api_key", "")
    if not key:
        sys.exit("Founder Error, check your Groq API key, your internet connection and the Groq service status (https://status.groq.com) to resolve this issue.")
    return ("groq", "https://api.groq.com/openai/v1", settings["llm_model"], key)


def chat(settings, messages, max_tokens=1400, json_mode=False):
    _, base, model, key = llm_endpoint(settings)
    url = base.rstrip("/") + "/chat/completions"
    body = {
        "model": model, "messages": messages, "temperature": 0.2, "max_tokens": max_tokens,
    }
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    payload = json.dumps(body).encode()
    req = urllib.request.Request(url, data=payload)
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {key}")
    req.add_header("User-Agent", "Founder/1.0 (macOS)")
    last = None
    for attempt in range(1, 4):
        try:
            with urllib.request.urlopen(req, timeout=180) as resp:
                data = json.loads(resp.read().decode())
            msg = data["choices"][0]["message"]
            content = (msg.get("content") or "").strip()
            if not content:
                content = (msg.get("reasoning") or "").strip()
            return content
        except urllib.error.HTTPError as e:
            last = RuntimeError(f"LLM error {e.code}: {e.read().decode(errors='replace')[:400]}")
            log(f"LLM attempt {attempt}/3 failed (HTTP {e.code})")
        except Exception as e:
            last = e
            log(f"LLM attempt {attempt}/3 failed: {e}")
        time.sleep(attempt * 2)
    raise RuntimeError("Founder Error, check your Groq API key, your internet connection and the Groq service status (https://status.groq.com) to resolve this issue.") from last


def extract_json(text):
    text = re.sub(r"```(?:json)?", "", text).strip()
    if "[" in text and "]" in text:
        start, end = text.find("["), text.rfind("]")
        return json.loads(text[start:end + 1])
    if "{" in text and "}" in text:
        start, end = text.find("{"), text.rfind("}")
        return [json.loads(text[start:end + 1])]
    raise ValueError("No JSON array in LLM reply")


def parse_tasks(settings, task_lines, summary):
    prompt = "\n".join(task_lines)
    system = (
        "You are an experienced executive assistant turning today's rough to-do list into "
        "structured JSON, ready to be scheduled. Return ONLY a JSON array. Each element: {\n"
        "  \"description\": string,\n"
        "  \"minutes\": int (>0),            # your best duration estimate\n"
        "  \"deadline\": \"HH:MM\" | null,    # must finish by this time\n"
        "  \"fixed\": \"HH:MM\" | null,       # must start at exactly this time\n"
        "  \"after\": \"HH:MM\" | null,       # must not start BEFORE this time\n"
        "  \"focus\": \"deep\" | \"light\"    # deep = needs uninterrupted concentration\n"
        "}\n"
        "Think like a real planner, not a literalist:\n"
        " - Make confident, sensible assumptions: realistic durations that include setup, "
        "   cleanup and transitions (round UP, never undershoot).\n"
        " - If a line is vague or bundles several steps, split it into the 2-3 concrete "
        "   actions a person would actually take and estimate each.\n"
        " - Use the fixed-day context when inferring times: 'before work', 'after the gym', "
        "   'during lunch', etc. — never schedule a task into a locked block.\n"
        " - Infer focus sensibly: deep/problem-solving/creative work = deep; quick "
        "   communication, errands, chores = light.\n"
        " - Work ONLY from the given lines — never invent tasks the person didn't ask for.\n"
        "Drop pure filler (\"wake up\", \"check phone\"). Estimate minutes when unknown "
        "(default 30). Empty list -> []."
    )
    messages = [
        {"role": "system", "content": system + "\nFixed parts of the day:\n" + (summary or "none")},
        {"role": "user", "content": prompt},
    ]
    raw = chat(settings, messages, max_tokens=4096, json_mode=True)
    try:
        items = extract_json(raw)
    except ValueError:
        log("LLM reply unparseable; retrying once.")
        items = extract_json(chat(settings, messages, max_tokens=4096, json_mode=True))
    out = []
    for i, item in enumerate(items, start=1):
        desc = str(item.get("description") or "").strip()
        if not desc:
            continue
        try:
            minutes = int(item.get("minutes"))
        except (TypeError, ValueError):
            minutes = 0
        if minutes < 5:
            minutes = settings["default_task_min"]
        for k in ("deadline", "fixed", "after"):
            v = item.get(k) or None
            if v is not None:
                try:
                    tmin(v)
                except (TypeError, ValueError):
                    v = None
            item[k] = v
        focus = str(item.get("focus") or "light").lower()
        out.append({
            "id": i, "description": desc, "minutes": minutes,
            "deadline": item["deadline"], "fixed": item["fixed"],
            "after": item.get("after"), "focus": "deep" if focus == "deep" else "light",
        })
    return out


# ---------------------------------------------------------------------------
#  CONSTRAINTS  (the non-negotiables of your day, from constraints.txt)
#  Formats:
#    work: 09:00-17:00
#    school: 13:00-15:00
#    commute: 08:30-08:45, 17:45-18:00
#    lunch: 12:30 60min
#    block: Gym 18:00-19:00          (or "meeting:" / "appointment:")
#    peak: 09:00-12:00               (your deep-work window)
#    day: 08:00-22:00                (overall scheduling window)
# ---------------------------------------------------------------------------

# Day-aware constraints: any line may start with a filter token before the
# keyword, e.g. "@day1 block: ..." / "@tue block: ..." / "@weekend lunch: ...".
#   @weekday  @weekend   @mon @tue @wed @thu @fri @sat @sun   (mon-fri / sat)
#   @day1  @day2         alternating school days (skips weekends + holidays)
# `school-off:` (alias `holidays:`) lists extra days off: 2026-11-26, 2026-12-25
# US federal holidays are skipped for school automatically.

DAY1_ANCHOR = dt.date(2026, 9, 11)     # every school day alternates from here
WEEKDAY_NUM = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}


def federal_holidays(year):
    days = set()

    def nth_wd(m, wd, n):
        d = dt.date(year, m, 1)
        while d.weekday() != wd:
            d += dt.timedelta(days=1)
        return d + dt.timedelta(days=7 * (n - 1))

    def last_wd(m, wd):
        d = dt.date(year, m + 1, 1) - dt.timedelta(days=1)
        while d.weekday() != wd:
            d -= dt.timedelta(days=1)
        return d

    days.add(dt.date(year, 1, 1))                       # New Year's Day
    days.add(nth_wd(1, 0, 3))                           # MLK Jr. Day
    days.add(nth_wd(2, 0, 3))                           # Washington's Birthday
    days.add(last_wd(5, 0))                             # Memorial Day
    days.add(dt.date(year, 6, 19))                      # Juneteenth
    j4 = dt.date(year, 7, 4)                            # Independence (observed)
    days.add(j4 - dt.timedelta(days=1) if j4.weekday() == 5 else
             j4 + dt.timedelta(days=1) if j4.weekday() == 6 else j4)
    days.add(nth_wd(9, 0, 1))                           # Labor Day
    days.add(nth_wd(10, 0, 2))                          # Columbus Day
    days.add(dt.date(year, 11, 11))                     # Veterans Day
    th = dt.date(year, 11, 1)                           # Thanksgiving (4th Thu)
    while th.weekday() != 3:
        th += dt.timedelta(days=1)
    days.add(th + dt.timedelta(days=21))
    days.add(dt.date(year, 12, 25))                     # Christmas Day
    return days


def school_off_dates():
    out = set()
    for ln in read_lines(CONSTRAINTS_FILE):
        low = ln.lower().strip()
        if low.startswith(("school-off:", "holidays:")):
            for tok in re.findall(r"\d{4}-\d{2}-\d{2}", ln):
                try:
                    out.add(dt.date.fromisoformat(tok))
                except ValueError:
                    pass
    return out


def is_school_day(d, extra_off=()):
    if d.weekday() >= 5:
        return False
    if d in extra_off or d in federal_holidays(d.year):
        return False
    return True


def day_flag(d, extra_off=()):
    # 1 or 2 for a school day, alternates from DAY1_ANCHOR (== Day 1).
    if not is_school_day(d, extra_off):
        return None
    n = 1
    if d > DAY1_ANCHOR:
        n += sum(1 for i in range(1, (d - DAY1_ANCHOR).days + 1)
                 if is_school_day(DAY1_ANCHOR + dt.timedelta(days=i), extra_off))
    return 1 if n % 2 == 1 else 2


def parse_day_filter(tok):
    raw = tok.lower()
    m = re.match(r"every(\d+):(\d{4}-\d{2}-\d{2})$", raw)
    if m:
        return "recur", (int(m.group(1)), dt.date.fromisoformat(m.group(2)))
    if raw in ("school",):
        return "school", None
    if raw in ("weekday", "weekdays"):
        return "weekday", None
    if raw in ("weekend", "weekends"):
        return "weekend", None
    if raw in ("day1", "day2"):
        return "flag", int(raw[-1])
    wds = set()
    for part in raw.split(","):
        part = part.strip()
        if "-" in part:
            a = WEEKDAY_NUM.get(part.split("-", 1)[0].strip())
            b = WEEKDAY_NUM.get(part.split("-", 1)[1].strip())
            if a is None or b is None:
                continue
            a, b = (a, b) if a <= b else (b, a)
            wds.update(range(a, b + 1))
        else:
            v = WEEKDAY_NUM.get(part)
            if v is not None:
                wds.add(v)
    return "weekday_set", wds


def filter_day_matches(kind, val, d, extra_off):
    if kind == "recur":
        n, anchor = val
        return d >= anchor and (d - anchor).days % n == 0
    if kind == "school":
        return is_school_day(d, extra_off)
    if kind == "weekday":
        return d.weekday() < 5
    if kind == "weekend":
        return d.weekday() >= 5
    if kind == "flag":
        return day_flag(d, extra_off) == val
    return d.weekday() in val


def split_filters(raw, today, extra_off):
    filters = []
    body = raw
    low = raw.lower()
    while low.startswith("@"):
        tok = low.split(None, 1)[0]
        filters.append(parse_day_filter(tok[1:]))
        body = body[len(tok):].strip()
        low = body.lower()
    if any(not filter_day_matches(k, v, today, extra_off) for k, v in filters):
        return None
    return low, body


def constraint_blocks(settings, lines, today=None):
    today = today or dt.date.today()
    extra_off = school_off_dates()
    blocks = []
    rituals = []
    day_start = tmin(settings["day_start"])
    day_end = tmin(settings["day_end"])
    lunch_override = None
    for ln in lines:
        raw = ln.strip()
        if not raw or raw.startswith("#"):
            continue
        parsed = split_filters(raw, today, extra_off)
        if parsed is None:
            continue
        low, body = parsed
        if low.startswith(("work:", "school:", "class:", "commute:")):
            label, _, rest = body.partition(":")
            for span in re.findall(r"(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})", rest):
                blocks.append((tmin(span[0]), tmin(span[1]), "locked", label.strip().capitalize()))
        elif low.startswith("lunch:"):
            m = re.match(r"lunch:\s*(\d{1,2}:\d{2})\s*(?:(\d+)\s*min)?", low)
            if m:
                n = int(m.group(2)) if m.group(2) else settings["lunch_min"]
                lunch_override = (tmin(m.group(1)), n)
        elif low.startswith("meal:"):
            m = re.match(r"meal:\s*(.*?)\s+(\d+)\s*min\s+(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*$", low)
            if m:
                rituals.append((m.group(1).strip(), int(m.group(2)),
                                tmin(m.group(3)), tmin(m.group(4))))
        elif low.startswith(("block:", "meeting:", "appointment:")):
            m = re.match(r"^[^:]+:\s*(.*?)\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})\s*$", body)
            if m:
                blocks.append((tmin(m.group(2)), tmin(m.group(3)), "locked", m.group(1).strip()))
    has_lunch = any(b[3].strip().lower() == "lunch" for b in blocks)
    if not has_lunch and lunch_override:
        s, n = lunch_override
        blocks.append((s, s + n, "locked", "Lunch"))
    return blocks, day_start, day_end, rituals


def parse_constraints(settings, lines, today=None):
    today = today or dt.date.today()
    extra_off = school_off_dates()
    blocks, day_start, day_end, rituals = constraint_blocks(settings, lines, today)
    peak = None
    pref = ""
    for ln in lines:
        raw = ln.strip()
        if not raw or raw.startswith("#"):
            continue
        parsed = split_filters(raw, today, extra_off)
        if parsed is None:
            continue
        low, _ = parsed
        if low.startswith("peak:"):
            m = re.match(r"peak:\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})", low)
            if m:
                peak = (tmin(m.group(1)), tmin(m.group(2)))
        elif low.startswith("day:"):
            m = re.match(r"day:\s*(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})", low)
            if m:
                day_start, day_end = tmin(m.group(1)), tmin(m.group(2))
        elif low.startswith("prefer:"):
            pref = low.replace("prefer:", "").strip()
    return {
        "blocks": sorted(set(blocks)),
        "rituals": rituals,
        "peak": peak or (day_start, day_start + 180),
        "pref": pref,
        "day_start": day_start,
        "day_end": day_end,
    }


def constraint_summary(cons):
    return "; ".join(f"{label} {tstr(s)}-{tstr(e)}" for s, e, k, label in cons["blocks"])


# ---------------------------------------------------------------------------
#  PERSONALISATION  (learns from log.txt what you're fast at and what drains you)
# ---------------------------------------------------------------------------

def read_log():
    entries = []
    if LOG_FILE.exists():
        for ln in LOG_FILE.read_text().splitlines():
            ln = ln.strip()
            if not ln or ln.startswith("#") or "|" not in ln:
                continue
            parts = ln.split("|")
            if len(parts) >= 4:
                entries.append({"date": parts[0], "kind": parts[1], "desc": parts[2], "minutes": parts[3]})
    return entries


def personalization(entries):
    struggle_words, minute_map = set(), {}
    for e in entries:
        try:
            mins = int(e["minutes"])
        except ValueError:
            mins = 0
        if e["kind"] in ("skip", "struggle"):
            struggle_words.update(re.findall(r"[a-z]{4,}", e["desc"].lower()))
        elif e["kind"] == "done":
            minute_map.setdefault(e["desc"].lower().strip(), []).append(max(mins, 0))
    avg = {d: sum(v) / len(v) for d, v in minute_map.items() if v}
    return {"struggle_words": struggle_words, "avg": avg}


def apply_personalization(tasks, pers):
    for t in tasks:
        words = set(re.findall(r"[a-z]{4,}", t["description"].lower()))
        if words & pers["struggle_words"]:
            t["minutes"] = int(t["minutes"] * 1.25) + 10
            t["focus"] = "deep"
            t["struggle"] = True
        an = pers["avg"].get(t["description"].lower().strip())
        if an and an < t["minutes"] * 0.8:
            t["minutes"] = max(int(an), 15)
    return tasks


# ---------------------------------------------------------------------------
#  SCHEDULER  (deterministic: fits tasks into the free gaps you allow)
#  Block tuples are always (start_min, end_min, kind, label);
#  kind in {"locked", "task", "booked", "break"}, label is str or task-dict.
# ---------------------------------------------------------------------------

def earliest_gap(occ, start, duration, deadline):
    cursor = start
    for s, e in sorted(occ):
        if e <= cursor:
            continue
        if cursor + duration <= s and cursor + duration <= deadline:
            return cursor
        cursor = max(cursor, e)
    if cursor + duration <= deadline:
        return cursor
    return None


def schedule(tasks, cons, settings, done_ids=()):
    occ = [(s, e) for s, e, k, label in cons["blocks"]]
    blocks = list(cons["blocks"])
    ws, we = cons["day_start"], cons["day_end"]

    for t in tasks:
        if t["fixed"] and t["id"] not in done_ids:
            s = tmin(t["fixed"])
            occ.append((s, s + t["minutes"]))
            blocks.append((s, s + t["minutes"], "booked", t))

    flex = [t for t in tasks if not t["fixed"] and t["id"] not in done_ids]

    for label, minutes, rws, rwe in cons.get("rituals", []):
        start = earliest_gap(occ, rws, minutes, rwe)
        if start is None:
            continue
        occ.append((start, start + minutes))
        blocks.append((start, start + minutes, "task",
                       {"id": -1, "description": label, "minutes": minutes, "focus": "light"}))

    def key(t):
        return (0 if t["deadline"] else 1,
                tmin(t["deadline"]) if t["deadline"] else 2400,
                0 if t["focus"] == "deep" else 1,
                -t["minutes"])

    flex.sort(key=key)
    overflow = []
    for t in flex:
        lo = tmin(t["after"]) if t.get("after") else ws
        deadline = min(tmin(t["deadline"]) if t["deadline"] else we, we)
        start = earliest_gap(occ, lo, t["minutes"], deadline)
        if start is None:
            overflow.append(t)
            continue
        occ.append((start, start + t["minutes"]))
        blocks.append((start, start + t["minutes"], "task", t))

    blocks = insert_breaks(sorted(blocks, key=lambda b: b[0]), ws, we, settings)
    return blocks, overflow


def insert_breaks(blocks, ws, we, settings):
    every, bmin = settings["break_every_min"], settings["break_min"]
    work_blocks = [b for b in blocks if b[2] != "break"]
    out, worked = [], 0
    for i, (s, e, kind, label) in enumerate(work_blocks):
        if kind in ("task", "booked"):
            worked += e - s
        elif kind == "locked":
            worked = 0
        out.append((s, e, kind, label))
        if kind in ("task", "booked") and worked >= every:
            worked = 0
            ns = work_blocks[i + 1][0] if i + 1 < len(work_blocks) else we
            if ns - e >= bmin:
                out.append((e, e + bmin, "break", "Break"))
    return sorted(out, key=lambda b: b[0])


# ---------------------------------------------------------------------------
#  EMAIL OUT
# ---------------------------------------------------------------------------

def build_email_body(blocks, overflow, day_label, tasks, mode="plan",
                     prev_blocks=None, today_notes=None, rough_next=None):
    body_tags = {t["id"]: f"[t{t['id']}]" for t in tasks}
    prev_render = []
    if mode == "plan" and prev_blocks:
        prev_render.append("")
        prev_render.append("Yesterday at a glance:")
        for s, e, kind, label in prev_blocks:
            if kind == "break":
                prev_render.append(f"{tstr(s)} - {tstr(e)}    Break")
            elif kind == "locked":
                prev_render.append(f"{tstr(s)} - {tstr(e)}    {label}  (locked)")
            else:
                prev_render.append(f"{tstr(s)} - {tstr(e)}    {label['description']}")
    notes_render = []
    if mode == "plan" and today_notes:
        notes_render.append("")
        notes_render.append("Your notes for today:")
        notes_render.extend(f"  - {n}" for n in today_notes)
    rough_render = []
    if mode == "plan" and rough_next:
        rough_render.append("")
        rough_render.append(rough_next)

    lines = [f"Good morning! Here is your plan for {day_label}.", ""]
    if not blocks and not overflow and mode == "plan":
        lines.append("Your list was empty - enjoy the free day!")
        lines += prev_render + notes_render + rough_render
        return "\n".join(lines)
    lines.append("Your day at a glance:")
    for s, e, kind, label in blocks:
        time = f"{tstr(s)} - {tstr(e)}"
        if kind == "break":
            lines.append(f"{time}    {label}")
            continue
        if kind == "locked":
            lines.append(f"{time}    {label}  (locked)")
            continue
        tid = label["id"]
        tag = body_tags.get(tid, "")
        note = "  (deep focus)" if label.get("focus") == "deep" else ""
        lines.append(f"{time}    {label['description']}{note}  {tag}")
    if overflow:
        lines.append("")
        lines.append("Couldn't fit today - consider:")
        for t in overflow:
            note = f" (needed by {t['deadline']})" if t.get("deadline") else ""
            lines.append(f"  - {t['description']} ~{t['minutes']} min{note}")
    lines.append("")
    if mode == "plan":
        lines.append("Reply with 'done [t1]', 'skip [t2]', or 'add: <task>' and")
        lines.append("Founder will rebuild the rest of your day around your reply.")
    else:
        lines.append("Founder just rebuilt the rest of your day around today's list.")
    lines.append("")
    lines.append("Start with your deep-focus block before opening email. You've got this.")
    return "\n".join(lines)


def prev_day_blocks(today):
    entries = read_log()
    y = today - dt.timedelta(days=1)
    planned = [e for e in entries if e["date"] == y.isoformat() and e["kind"] == "planned"]
    planned.sort(key=lambda e: e["desc"])
    blocks, acc = [], 0
    for e in planned:
        try:
            m = int(e["minutes"])
        except ValueError:
            m = 0
        blocks.append((acc, acc + m, "task", {"description": e["desc"], "id": len(blocks) + 1}))
        acc += m + 10
    return blocks


def note_lines(task_lines):
    return [ln.lstrip()[1:].strip() for ln in task_lines if ln.strip().startswith("#")]


def rough_next_line(tasks, overflow, today):
    if today.weekday() >= 5:
        return "Weekend - refresh and recharge."
    stretch = [t["description"] for t in overflow][:3]
    candidates = stretch + [t["description"] for t in tasks[:2]]
    return "Tomorrow: " + "; ".join(candidates) if candidates else "Clear - tomorrow will shape itself from how today closes."


def esc(s):
    return html_escape.escape(str(s), quote=False)


def deadline_suffix_html(t):
    if t.get("deadline"):
        return " <span style='color:#e8853c'>needs: %s</span>" % t["deadline"]
    return ""


def build_email_html(blocks, overflow, day_label, tasks, mode="plan",
                     prev_blocks=None, today_notes=None, rough_next=None):
    body_tags = {t["id"]: f"[t{t['id']}]" for t in tasks}

    if not blocks and not overflow:
        return build_done_html(day_label)

    def row(start, end, kind, label):
        time = f"<span style='font-family:Menlo,Monaco,monospace;color:#98a2b3;font-size:12px;min-width:96px;display:inline-block'>{tstr(start)}&ndash;{tstr(end)}</span>"
        if kind == "break":
            return (f"<tr><td colspan='2' style='padding:6px 0'><div style='border-top:1px dashed #e4e7ec;"
                    f"padding:8px 0 2px;color:#98a2b3;font-size:12px;font-style:italic'>Break</div></td></tr>")
        if kind == "locked":
            chip = "<span style='background:#eef0f3;color:#667085;border-radius:6px;padding:2px 8px;font-size:11px;margin-left:8px'>locked</span>"
            return (f"<tr><td style='padding:5px 0'>{time}</td><td style='padding:5px 0'>"
                    f"<span style='color:#475467;font-weight:600'>{esc(label)}</span>{chip}</td></tr>")
        tid = label["id"]
        tag = body_tags.get(tid, "")
        deep = label.get("focus") == "deep"
        if deep:
            chip_bg, chip_fg, text = "#f3e8ff", "#7c3aed", "deep focus"
        else:
            chip_bg, chip_fg, text = "#eef4ff", "#2e5bd4", "focus"
        return (f"<tr><td style='padding:6px 0'>{time}</td><td style='padding:6px 0'>"
                f"<span style='background:{chip_bg};color:{chip_fg};border-radius:8px;padding:2px 10px;"
                f"font-size:12px;font-weight:600;margin-right:8px'>{text}</span>"
                f"<span style='color:#101828;font-weight:600'>{esc(label['description'])}</span>"
                f"<span style='color:#d0d5dd;font-family:Menlo,Monaco,monospace;font-size:12px;margin-left:8px'>{esc(tag)}</span>"
                f"</td></tr>")

    rows = "\n".join(row(*b) for b in blocks)
    overflow_html = ""
    if overflow:
        items = "".join(
            f"<li style='color:#667085;font-size:13px;padding:2px 0'>"
            f"{esc(t['description'])} <span style='color:#98a2b3'>~{t['minutes']} min</span>"
            f"{deadline_suffix_html(t)}</li>"
            for t in overflow)
        overflow_html = (f"<div style='background:#fff4e6;border:1px solid #fcd9b3;border-radius:10px;"
                         f"padding:14px 16px;margin:18px 0'><div style='font-weight:700;color:#b54708;"
                         f"font-size:13px;margin-bottom:6px'>Couldn't fit today</div><ul style='margin:0;padding-left:18px'>{items}</ul></div>")

    hint = ("Reply with <b>done [t1]</b>, <b>skip [t2]</b>, or <b>add: &lt;task&gt;</b> and "
            "Founder rebuilds the rest of your day."
            if mode == "plan" else
            "Founder just rebuilt the rest of your day around today's list.")

    return f"""<div style="max-width:600px;margin:0 auto;padding:24px 16px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">
  <div style="background:linear-gradient(135deg,#101828 0%,#1d2939 60%,#344054 100%);border-radius:16px;padding:28px 28px 26px;color:#ffffff">
    <div style="font-size:12px;letter-spacing:2px;color:#9fe8b4;font-weight:700;margin-bottom:6px">FOUNDER &middot; {esc('DAILY PLAN' if mode == 'plan' else 'UPDATED PLAN')}</div>
    <div style="font-size:24px;font-weight:800;line-height:1.25">{esc(day_label)}</div>
    <div style="color:#98a2b3;font-size:13px;margin-top:6px">Built for you while you slept. Deep focus is scheduled, locked time is respected.</div>
  </div>
  <div style="background:#ffffff;border:1px solid #e4e7ec;border-radius:0 0 16px 16px;padding:22px 26px 26px">
    <table style="width:100%;border-collapse:collapse">{rows}</table>
    {overflow_html}
    <div style="background:#f0f6ff;border-radius:10px;padding:12px 14px;font-size:13px;color:#1d2939;margin-top:18px">{hint}</div>
    <div style="color:#98a2b3;font-size:12px;margin-top:16px">Start with a deep-focus block before opening email. You've got this.</div>
  </div>
</div>"""


def build_done_html(day_label):
    return f"""<div style="max-width:600px;margin:0 auto;padding:24px 16px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">
  <div style="background:linear-gradient(135deg,#0e4224 0%,#128081 70%);border-radius:16px;padding:28px;color:#fff;text-align:center">
    <div style="font-size:12px;letter-spacing:2px;color:#b7f7c9;font-weight:700">FOUNDER</div>
    <div style="font-size:22px;font-weight:800;margin-top:8px">All clear for {esc(day_label)}</div>
    <div style="color:#d1fae5;font-size:14px;margin-top:8px">You cleared today's list. See you tomorrow.</div>
  </div>
</div>"""


def send_email(settings, subject, text, html=None):
    if html:
        msg = MIMEMultipart("alternative")
        msg.attach(MIMEText(text, "plain", "utf-8"))
        msg.attach(MIMEText(html, "html", "utf-8"))
    else:
        msg = MIMEText(text, "plain", "utf-8")
    msg["Subject"] = Header(subject, "utf-8")
    msg["From"] = f"{settings['email_from']} <{settings['email_from']}>"
    msg["To"] = settings["email_to"]
    try:
        server = smtplib.SMTP(settings["smtp_host"], settings["smtp_port"], timeout=30)
        server.ehlo()
        if settings.get("smtp_starttls"):
            server.starttls()
            server.ehlo()
        if settings["mail_username"]:
            server.login(settings["mail_username"], settings["mail_password"])
        server.send_message(msg)
        server.quit()
        log(f"Sent: {subject}")
    except Exception as e:
        log(f"EMAIL FAILED ({e}); FYI the body was:\n{text}")
        raise


# ---------------------------------------------------------------------------
#  EMAIL IN  (reads replies from the planner's inbox)
# ---------------------------------------------------------------------------

def imap_connect(settings):
    m = imaplib.IMAP4_SSL(settings["imap_host"], settings["imap_port"])
    m.login(settings["mail_username"], settings["mail_password"])
    m.select("INBOX")
    return m


def body_text(msg):
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_payload(decode=True)
                return payload.decode(errors="replace") if payload else part.get_payload()
    payload = msg.get_payload(decode=True)
    if payload:
        return payload.decode(errors="replace")
    return str(msg.get_payload() or "")


def decide_status(window):
    if any(w in window for w in SKIP_WORDS):
        return "skip"
    return "done"


STOP = {"write", "call", "reply", "send", "review", "make", "ask", "check", "update",
        "finish", "complete", "the", "and", "with", "for", "to", "before", "after"}


def classify_reply(text, tasks):
    low = text.lower()
    results = {}
    tag_done = re.compile(r"(?:done|finished|finish|completed|complete|ok|wrapped|cleared)\s+(?:with\s+|on\s+)?\[t(\d+)\]")
    tag_skip = re.compile(r"(?:didn.t|didnt|couldn.t|couldnt|not\s+done|skipped|skip|cancel|pushed|struggled|gave\s+up|too\s+(?:long|much)|failed|won.t|wont)\s*\[t(\d+)\]")
    for m in tag_done.finditer(low):
        results[int(m.group(1))] = "done"
    for m in tag_skip.finditer(low):
        results[int(m.group(1))] = "skip"
    for t in tasks:
        tag = f"[t{t['id']}]"
        if t["id"] not in results and tag in low:
            results[t["id"]] = decide_status(low)
            continue
        if t["id"] in results:
            continue
        words = [w for w in re.findall(r"[a-z]{4,}", t["description"].lower())]
        sig = [w for w in words if w not in STOP] or words
        present = [w for w in sig if w in low]
        if present and len(present) >= max(1, len(sig) // 2):
            for w in present:
                for m in re.finditer(r"\b" + re.escape(w) + r"\b", low):
                    window = low[max(0, m.start() - 160): m.end() + 160]
                    if any(d in window for d in DONE_WORDS):
                        results[t["id"]] = "done"
                        break
                if t["id"] in results:
                    break
    return results


def parse_additions(text):
    adds = []
    for ln in text.splitlines():
        m = re.match(r"^\s*(?:add|new|todo|note)(?:\s*|:)\s+(.+?)\s*$", ln, re.IGNORECASE)
        if m:
            adds.append(m.group(1).strip())
            continue
        m2 = re.match(r"^\s*[-*]\s+(.+?)\s*$", ln)
        if m2:
            adds.append(m2.group(1).strip())
    return adds


def apply_updates(settings, state, updates, additions, today):
    tasks = state.get("tasks", [])
    if additions:
        with open(TASKS_FILE, "a", encoding="utf-8") as f:
            f.write("\n".join(additions) + "\n")
        log(f"Added from reply: {additions}")
    for t in tasks:
        if t["id"] in updates:
            t["status"] = updates[t["id"]]
            log_event(today, updates[t["id"]], t["description"], t["minutes"])
    remaining = [t for t in tasks if t.get("status") not in ("done", "skip")]
    day_label = dt.date.today().strftime("%A, %B %-d")
    if additions:
        cons = parse_constraints(settings, read_lines(CONSTRAINTS_FILE))
        new_tasks = apply_personalization(
            parse_tasks(settings, additions, constraint_summary(cons)),
            personalization(read_log()))
        remaining += new_tasks
    if not remaining:
        send_email(settings, "[FNDR] All clear for today",
                   build_email_body([], [], day_label, [], mode="update"),
                   html=build_done_html(day_label))
        return
    for i, t in enumerate(remaining, start=1):
        t["id"] = i
    cons = parse_constraints(settings, read_lines(CONSTRAINTS_FILE))
    blocks, overflow = schedule(remaining, cons, settings,
                                done_ids=[t["id"] for t in tasks if t.get("status") == "done"])
    send_email(settings, "[FNDR] Updated plan for today",
               build_email_body(blocks, overflow, day_label, remaining, mode="update"),
               html=build_email_html(blocks, overflow, day_label, remaining, mode="update"))
    state["tasks"] = remaining
    save_state(state)


def check_replies(settings, force=False):
    state = load_state()
    today = dt.date.today().isoformat()
    if state.get("plan_date") != today and not force:
        log("No active plan; skipping inbox poll.")
        return
    tasks = state.get("tasks", [])
    try:
        m = imap_connect(settings)
    except Exception as e:
        log(f"IMAP connect failed: {e}")
        return
    seen = set(state.get("seen_uids", []))
    try:
        typ, data = m.search(None, '(SUBJECT "[FNDR]" UNSEEN)')
        updates, additions = {}, []
        for uid in (data[0].split() if typ == "OK" and data else []):
            uid = uid.decode()
            if uid in seen:
                continue
            typ2, msg_data = m.fetch(uid, "(RFC822)")
            if typ2 != "OK" or not msg_data or msg_data[0] is None:
                continue
            msg = message_from_bytes(msg_data[0][1])
            if "[FNDR]" not in str(msg.get("Subject", "")):
                continue
            text = body_text(msg)
            for tid, st in classify_reply(text, tasks).items():
                updates.setdefault(tid, st)
            additions.extend(parse_additions(text))
            seen.add(uid)
            if updates or additions:
                try:
                    m.store(uid, "+FLAGS", "\\Seen")
                except Exception:
                    pass
        if updates or additions:
            log(f"Reply parsed: {updates} adds={additions}")
            apply_updates(settings, state, updates, additions, today)
        else:
            log("No actionable replies.")
        state["seen_uids"] = sorted(seen)
        save_state(state)
    except Exception as e:
        log(f"IMAP check error: {e}")
    finally:
        try:
            m.logout()
        except Exception:
            pass


#  WEEKLY DIGEST
# ---------------------------------------------------------------------------

def week_stats(entries, today=None):
    today = today or dt.date.today()
    week = [e for e in entries
            if 0 <= (today - dt.date.fromisoformat(e["date"])).days < 7 and e["date"] <= today.isoformat()]
    done = [e for e in week if e["kind"] == "done"]
    missed = [e for e in week if e["kind"] in ("skip", "struggle")]
    names = [e["desc"] for e in done]
    top = sorted({n: names.count(n) for n in set(names)}.items(), key=lambda kv: -kv[1])[:5]
    days_done = {e["date"] for e in done}
    streak = 0
    for i in range(1, 15):
        if (today - dt.timedelta(days=i)).isoformat() in days_done:
            streak += 1
        else:
            break
    total_min = sum((int(e["minutes"]) or 0) for e in done)
    return {
        "done": len(done), "focus_min": total_min, "missed": len(missed),
        "top": top, "streak": streak, "watchouts": sorted({e["desc"] for e in missed})[:5],
    }


def build_digest(entries, today=None):
    s = week_stats(entries, today)
    lines = ["Your weekly founder digest.", "",
             f"Completed: {s['done']}  |  Focus time: {s['focus_min'] // 60}h {s['focus_min'] % 60}m  |  Missed: {s['missed']}"]
    if s["top"]:
        lines.append("")
        lines.append("Most frequent wins:")
        lines += [f"  - {n} (x{c})" for n, c in s["top"]]
    if s["streak"]:
        lines.append("")
        lines.append(f"Milestone: {s['streak']}-day completion streak. Keep the chain alive!")
    if s["watchouts"]:
        lines.append("")
        lines.append("Watch-outs (Founder will give these more time next week):")
        lines += [f"  - {n}" for n in s["watchouts"]]
    lines += ["", "Mark tasks with ' [done]' in daily_tasks.txt as you clear them.",
              "That is how Founder learns what you finish fast."]
    return "\n".join(lines)


def build_digest_html(entries, today=None):
    s = week_stats(entries, today)

    def stat_cell(value, label, accent):
        return (f"<div style='flex:1;background:#f8fafc;border:1px solid #e4e7ec;border-radius:12px;"
                f"padding:14px;text-align:center;margin:0 4px'>"
                f"<div style='font-size:22px;font-weight:800;color:{accent}'>{value}</div>"
                f"<div style='font-size:11px;color:#98a2b3;letter-spacing:.5px;margin-top:4px'>{label}</div></div>")

    wins = ""
    if s["top"]:
        wins = "".join(
            f"<tr><td style='padding:7px 0;color:#344054;font-weight:600'>{esc(n)}</td>"
            f"<td style='padding:7px 0;text-align:right'><span style='background:#eef4ff;color:#2e5bd4;"
            f"border-radius:999px;padding:2px 10px;font-size:12px;font-weight:700'>x{c}</span></td></tr>"
            for n, c in s["top"])
        wins = (f"<div style='margin-top:18px'><div style='font-weight:700;color:#101828;font-size:13px;"
                f"margin-bottom:4px'>Most frequent wins</div><table style='width:100%;border-collapse:collapse'>{wins}</table></div>")
    watch = ""
    if s["watchouts"]:
        chips = "".join(f"<span style='display:inline-block;background:#fff4e6;color:#b54708;border:1px solid #fcd9b3;"
                        f"border-radius:8px;padding:4px 10px;font-size:12px;margin:3px 3px 0 0'>{esc(n)}</span>" for n in s["watchouts"])
        watch = f"<div style='margin-top:18px'><div style='font-weight:700;color:#101828;font-size:13px;margin-bottom:6px'>Watch-outs &middot; getting more time next week</div>{chips}</div>"
    streak = ""
    if s["streak"]:
        streak = (f"<div style='margin-top:18px;background:linear-gradient(135deg,#0e4224,#128081);color:#fff;"
                  f"border-radius:12px;padding:14px 16px;text-align:center'>"
                  f"<div style='font-size:13px;font-weight:700'>{s['streak']}-day completion streak</div>"
                  f"<div style='font-size:12px;color:#d1fae5;margin-top:4px'>Keep the chain alive.</div></div>")

    return f"""<div style="max-width:600px;margin:0 auto;padding:24px 16px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif">
  <div style="background:linear-gradient(135deg,#101828 0%,#1d2939 70%);border-radius:16px;padding:26px;color:#fff">
    <div style="font-size:12px;letter-spacing:2px;color:#9fe8b4;font-weight:700">FOUNDER &middot; WEEKLY DIGEST</div>
    <div style="font-size:22px;font-weight:800;margin-top:6px">Your week in review</div>
  </div>
  <div style="background:#fff;border:1px solid #e4e7ec;border-radius:0 0 16px 16px;padding:22px 24px">
    <div style="display:flex;justify-content:space-between">
      {stat_cell(s['done'], 'TASKS DONE', '#12b76a')}
      {stat_cell(f"{s['focus_min'] // 60}h {s['focus_min'] % 60}m", 'FOCUS TIME', '#2e5bd4')}
      {stat_cell(s['missed'], 'MISSED', '#e8853c')}
    </div>
    {wins}{streak}{watch}
    <div style="color:#98a2b3;font-size:12px;margin-top:18px">Mark tasks with ' [done]' in daily_tasks.txt, and Founder learns what you finish fast.</div>
  </div>
</div>"""


def send_digest(settings):
    today = dt.date.today()
    state = load_state()
    if state.get("digest_sent") == today.isoformat():
        log("Digest already sent today.")
        return
    text = build_digest(read_log(), today)
    send_email(settings, f"[FNDR] Weekly digest - week of {today.strftime('%b %d')}", text,
               html=build_digest_html(read_log(), today))
    state["digest_sent"] = today.isoformat()
    save_state(state)


# ---------------------------------------------------------------------------
#  MAIN FLOW
# ---------------------------------------------------------------------------

def plan_today(settings, dry_run=False, mode="plan"):
    today = dt.date.today()
    day_label = today.strftime("%A, %B %-d")
    task_lines, finished = split_done(read_lines(TASKS_FILE))
    for ln in finished:
        desc = re.sub(r"\s*\[done\]\s*$", "", ln, flags=re.IGNORECASE).strip()
        log_event(today.isoformat(), "done", desc, 0)
    if finished:
        log(f"Logged {len(finished)} finished task(s).")
    cons = parse_constraints(settings, read_lines(CONSTRAINTS_FILE))
    subject_prefix = "Updated plan for" if mode == "update" else "Your plan for"

    if not task_lines:
        log("No tasks in daily_tasks.txt; sending a free-day note.")
        prev_blocks = prev_day_blocks(today)
        notes = note_lines(read_lines(TASKS_FILE))
        rough_next = (read_lines(TASKS_FILE) if today.weekday() != 4
                      else ["Weekend - refresh and recharge."])
        body = build_email_body([], [], day_label, [], mode=mode,
                                prev_blocks=prev_blocks, today_notes=notes, rough_next=rough_next)
        if not dry_run:
            send_email(settings, f"[FNDR] {subject_prefix} {day_label}", body,
                       html=build_email_html([], [], day_label, [], mode=mode,
                                             prev_blocks=prev_blocks, today_notes=notes,
                                             rough_next=rough_next))
        else:
            print(body)
        return

    tasks = parse_tasks(settings, task_lines, constraint_summary(cons))
    tasks = apply_personalization(tasks, personalization(read_log()))
    blocks, overflow = schedule(tasks, cons, settings)
    prev_blocks = prev_day_blocks(today)
    today_notes = note_lines(read_lines(TASKS_FILE))
    rough_next = rough_next_line(tasks, overflow, today)
    body = build_email_body(blocks, overflow, day_label, tasks, mode=mode,
                            prev_blocks=prev_blocks, today_notes=today_notes, rough_next=rough_next)
    html = build_email_html(blocks, overflow, day_label, tasks, mode=mode,
                            prev_blocks=prev_blocks, today_notes=today_notes, rough_next=rough_next)

    if dry_run:
        log(f"SUBJECT: [FNDR] {subject_prefix} " + day_label)
        print("-" * 56)
        print(body)
        return

    send_email(settings, f"[FNDR] {subject_prefix} {day_label}", body, html=html)
    log_planned(today, tasks)
    state = load_state()
    state.update({"plan_date": today.isoformat(), "plan_sent_date": today.isoformat(), "tasks": tasks})
    save_state(state)
    log(f"Planned {len(tasks)} tasks.")


def setup_power(settings):
    cmd = ["pmset", "repeat", "wakeorpoweron", "MTWRFSU", settings["wake"] + ":00",
           "sleep", "MTWRFSU", settings["sleep"] + ":00"]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode == 0:
            log(f"Power schedule set: wake {settings['wake']}, sleep {settings['sleep']}.")
            return
        log("Needs an admin password. Run:")
        print("  sudo " + " ".join(cmd))
    except Exception as e:
        log(f"Could not set power schedule: {e}")


def rollover_tasks():
    today = dt.date.today().isoformat()
    lines = read_lines(TASKS_FILE)
    active, finished = split_done(lines)
    for ln in finished:
        desc = re.sub(r"\s*\[done\]\s*$", "", ln, flags=re.IGNORECASE).strip()
        log_event(today, "done", desc, 0)
    if active:
        TASKS_FILE.write_text("\n".join(active) + "\n", encoding="utf-8")
        log(f"Rollover {settings['rollover_hour']}:00 - {len(active)} unfinished task(s) carry into tomorrow.")
    else:
        if TASKS_FILE.exists():
            TASKS_FILE.write_text("", encoding="utf-8")
        log("Rollover - daily list cleared.")


def clear_tasks():
    if TASKS_FILE.exists():
        TASKS_FILE.write_text("", encoding="utf-8")
    log(f"{settings['clear_hour']}:00 clear - daily list emptied for tomorrow.")


def auto_route(settings):
    now = dt.datetime.now()
    h = now.hour
    today = dt.date.today().isoformat()
    state = load_state()

    # If today's plan hasn't been emailed yet (the Mac was asleep at the plan
    # hour, launchd missed the slot, or the 06:00 run hit a transient SMTP/LLM
    # error), send it at the first chance we get before the day rolls over —
    # never silently skip the whole day.
    if (state.get("plan_sent_date") != today
            and settings["plan_hour"] <= h < settings["rollover_hour"]):
        try:
            plan_today(settings)
        except Exception as e:
            log(f"PLAN FAILED this run ({e}); will retry on the next hour.")
        else:
            state = load_state()
            state["plan_sent_date"] = today
            save_state(state)
        finally:
            state = load_state()

    if h == settings["plan_hour"]:
        if now.weekday() == settings["digest_day"] and state.get("digest_sent") != today:
            send_digest(settings)
    elif settings["plan_hour"] < h < settings["rollover_hour"]:
        if state.get("plan_sent_date") == today and state.get("last_check") != h:
            check_replies(settings)
            state = load_state()
            state["last_check"] = h
            save_state(state)
    elif h == settings["rollover_hour"]:
        if state.get("rollover_date") != today:
            rollover_tasks()
            state = load_state()
            state["rollover_date"] = today
            save_state(state)
    elif h == settings["clear_hour"]:
        if state.get("clear_date") != today:
            clear_tasks()
            state = load_state()
            state["clear_date"] = today
            save_state(state)
    else:
        log("Outside planner hours - powered down via pmset.")


def add_task(text):
    text = text.strip()
    if not text:
        log("Nothing to add.")
        return
    with open(TASKS_FILE, "a", encoding="utf-8") as f:
        f.write(text + "\n")
    log(f"Added: {text}")
    print(f"Added to {TASKS_FILE.name}: {text}")


def split_done(task_lines):
    active, finished = [], []
    for ln in task_lines:
        if re.search(r"\[done\]$", ln, re.IGNORECASE):
            finished.append(ln)
        else:
            active.append(ln)
    return active, finished


def main():
    ap = argparse.ArgumentParser(description="Founder - your daily AI schedule planner")
    ap.add_argument("--add", metavar="TEXT", help="Append a task to daily_tasks.txt")
    ap.add_argument("--replan", action="store_true", help="Send an updated plan for today now")
    ap.add_argument("--plan", action="store_true", help="Force today's plan email")
    ap.add_argument("--check", action="store_true", help="Poll the inbox for replies now")
    ap.add_argument("--digest", action="store_true", help="Force the weekly digest email")
    ap.add_argument("--setup-power", action="store_true", help="Install wake/sleep schedule")
    ap.add_argument("--dry-run", action="store_true", help="Print the plan without emailing")
    args = ap.parse_args()

    if args.setup_power:
        setup_power(settings)
    elif args.add:
        add_task(args.add)
    elif args.replan:
        plan_today(settings, mode="update")
    elif args.dry_run:
        plan_today(settings, dry_run=True)
    elif args.plan:
        plan_today(settings)
    elif args.check:
        check_replies(settings, force=True)
    elif args.digest:
        send_digest(settings)
    else:
        auto_route(settings)


settings = SETTINGS
if __name__ == "__main__":
    main()
