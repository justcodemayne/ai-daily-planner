#!/bin/bash
# Install Founder as a LaunchAgent (runs founder.py hourly, 6AM-10PM).
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"
PLIST="$HOME/Library/LaunchAgents/com.founder.planner.plist"

cp "$DIR/com.founder.planner.plist" "$PLIST"
sed -i '' "s|/ABSOLUTE/PATH/TO/ai-daily-planner|$DIR|g" "$PLIST"
launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST"
echo "Installed: $PLIST"
echo "Verify with: launchctl list | grep founder"

echo ""
echo "If you want the Mac to WAKE for the day (6AM) and SLEEP at night, run:"
echo "  sudo python3 \"$DIR/founder.py\" --setup-power"